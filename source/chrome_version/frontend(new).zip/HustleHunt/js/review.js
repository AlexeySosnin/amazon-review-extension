getReviews = async (asin, star) => {
    var category = ['', 'one_star', 'two_star', 'three_star'];
    return new Promise(e => {
        $.ajax({
            method: 'POST',
            url: 'https://www.amazon.com/hz/reviews-render/ajax/reviews/get/ref=cm_cr_unknown',
            headers: {
                accept: 'text/html, */*',
            },
            data: {
                sortBy: '',
                reviewerType: 'all_reviews',
                formatType: '',
                mediaType: '',
                filterByStar: category[star],
                pageNumber: 1,
                filterByLanguage: '',
                filterByKeyword: '',
                shouldAppend: undefined,
                deviceType: 'desktop',
                canShowIntHeader: undefined,
                reftag: 'cm_cr_unknown',
                pageSize: 10,
                asin: asin,
                scope: 'reviewsAjax0',
            },
            success: () => {
                e([]);
            },
            error: data => {
                var reviews = [], temp, elem;
                if (data.readyState == 4 && data.status == 200 && data.statusText == 'parsererror') {
                    data.responseText.split('&&&').forEach(d => {
                        try {
                            temp = JSON.parse(d);
                            if (temp[0] == 'append') {
                                elem = $('<div></div>').html(temp[2]).find('span[data-hook="review-body"] span').text();
                                if (elem) {
                                    reviews.push(elem);
                                }
                            }
                        } catch(err) {
                        }
                    });
                }
                e(reviews);
            }
        });
    });
}

const url = 'https://analysis-api.hustlehunt.com'

getNegativeKeywords = async (words, top_k, typePage, asin) => {
    return new Promise(e => {
        $.ajax({
            method: 'POST',
            url: url + '/analysis',
            beforeSend: function(request) {
                request.setRequestHeader("Access-Control-Allow-Origin", "*");
            },
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'Access-Control-Allow-Origin': '*',
            },
            data: JSON.stringify({
                content: words.join(' '),
                top_k: top_k,
                sort: 'desc',
            }),
            success: (data) => {
                displayNegativeInPage(data, typePage, asin);
                e(data)
            },
            error: (error) => {
                console.log(error)
            }
        });
    });
}

displayNegativeInPage = (words, typePage, asin) => {
    if (words.length === 0) return;
    var html = '';
    html += '<div class="keywords">'
    html += typePage === 'detail' ? '<span><h3>Negative Keywords:</h3></span> ' : '';
    for (w of words) {
        html += `<span class="badge badge-light">"${w.keyword}" (${w.frequency})</span>`;
    }
    html += '</div>';

    if (typePage === 'detail') $("#dp-container").prepend(html);
    else if (typePage === 'feed') {
        $(`[data-asin="${asin}"] .sg-col-inner .s-include-content-margin`).append(html);
    }

    return html;
}

addStyle = () => {
    var style = `
        <style>
            .keywords {
                background: #eee;
                position: relative;
                min-height: 30px;
                padding: 5px 3px;
                border-radius: 4px;
                font-size: 12px;
                margin-bottom: 10px;
            }

            .badge {
                border: 1px solid #ddd;
                margin: 3px;
                color: #000;
                display: inline-flex;
                padding: 2px 5px;
                border-radius: 4px;
            }

            .badge-light {
                background: #fff;
            }
        </style>
    `

    $(style).appendTo("head");
}