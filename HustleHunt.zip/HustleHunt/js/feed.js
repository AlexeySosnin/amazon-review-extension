$(function() {
    chrome.runtime.sendMessage({
        method: 'Loading',
    });
    addStyle();
    scrapProducts();
});

scrapProducts = async () => {
    var products = [], that, rating, value, img, title, reviews, price, star, asin, words;
    var items = $('[data-component-type="s-search-result"].s-result-item');
    for (j = 0; j < items.length; j++) {
        that = $(items[j]);
        rating = that.find('.a-icon-alt').text();
        value = rating.split(' ')[0];
        if (value >= 3.0 && value <= 4.2) {
            img = that.find('.s-image').attr('src');
            title = that.find('h2 span').text();
            price = that.find('.a-price:not([data-a-strike]) .a-offscreen').text();
            reviews = that.find('a.a-link-normal .a-size-base').text();
            star = that.find('.a-icon.a-icon-star-small').attr('class');
            asin = that.data('asin');
            words = [];
            for (i = 3; i > 0; i--) {
                words = words.concat(await getReviews(asin, i));
                if (words.length >= 10) break;
            }
            negative_words = await getNegativeKeywords(words, 10);
            products.push({
                img: img,
                title: title,
                price: price,
                reviews: reviews,
                rating: rating,
                star: star,
                words: words,
                negative_words: negative_words,
            });
            showNegativeInFeed(negative_words, asin);
        }
    }
    chrome.runtime.sendMessage({
        method: 'Products',
        products: products,
    });
}

showNegativeInFeed = (words, asin) => {
    if (words.length === 0) return;
    var html = '';
    html += '<div class="keywords">'
    for (w of words) {
        html += `<span class="badge badge-light">"${w.keyword}" (${w.frequency})</span>`;
    }
    html += '</div>';

    $(`[data-asin="${asin}"] .sg-col-inner .s-include-content-margin`).append(html);
}

addStyle = () => {
    var style = `
        <style>
            .keywords {
                background: #eee;
                position: relative;
                min-height: 30px;
                padding: 5px 3px;
                border-radius: 4px;
                font-size: 12px;
            }

            .badge {
                border: 1px solid #ddd;
                margin: 3px;
                color: #000;
                display: inline-flex;
                padding: 2px 5px;
                border-radius: 4px;
            }

            .badge-light {
                background: #fff;
            }
        </style>
    `

    $(style).appendTo("head");
}